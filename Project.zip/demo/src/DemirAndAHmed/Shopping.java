package DemirAndAHmed;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

class Shopping {
	private static WebDriver webDriver;
	private static String baseUrl;
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Demir\\Desktop\\chromedriver.exe");
		webDriver = new ChromeDriver();
		baseUrl = "https://www.ekupi.ba/bs/";
		webDriver.get(baseUrl);	
		webDriver.manage().window().maximize();
		Thread.sleep(2000);	
		if (webDriver.findElement(By.xpath("/html/body/div[7]/div[2]/div/webpushrpromptconatiner/webpushrwppromptbox2_wrapper/webpushrpromptbox2/webpushrpromptbuttons2/webpushrpromptbtndeny2")).isDisplayed()){
			webDriver.findElement(By.xpath("/html/body/div[7]/div[2]/div/webpushrpromptconatiner/webpushrwppromptbox2_wrapper/webpushrpromptbox2/webpushrpromptbuttons2/webpushrpromptbtndeny2")).click();
		}
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	    Thread.sleep(2000);
		webDriver.close();
	}

	@Test
	void testList() throws InterruptedException {
	    webDriver.findElement(By.xpath("/html/body/main/header/nav[3]/div/ul[2]/li[14]/span[1]/a")).click();
		assertTrue("https://www.ekupi.ba/bs/Auto-i-moto-oprema/c/10005", true);
	    webDriver.findElement(By.xpath("//*[@id=\"product-facet\"]/div/div/div[2]/ul/li[1]/a")).click();
	    webDriver.findElement(By.xpath("//*[@id=\"product-facet\"]/div/div/div[2]/ul/li[1]/span/a")).click();
	    webDriver.findElement(By.xpath("//*[@id=\"product-facet\"]/div[2]/div[2]/ul/li[1]/form/label/span/span[1]")).click();
	    webDriver.findElement(By.xpath("//*[@id=\"product-facet\"]/div[4]/div[2]/ul/li[1]/form/label/span/span[1]")).click();
		Thread.sleep(3000);
	}
	@Test
	void testAdd() throws InterruptedException {
	    webDriver.findElement(By.xpath("/html/body/main/header/nav[3]/div/ul[2]/li[5]/span/a")).click();
		webDriver.findElement(By.xpath("/html/body/main/div[5]/div[1]/div[2]/div[1]/div[1]/div/form/label/span/div/input[1]")).sendKeys("30");
		Thread.sleep(2000);
	    webDriver.findElement(By.xpath("/html/body/main/div[5]/div[1]/div[2]/div[1]/div[1]/div/form/label/span/div/span/button")).click();
	    JavascriptExecutor js = (JavascriptExecutor) webDriver;
		WebElement element = webDriver.findElement(By.xpath("/html/body/main/div[5]/div[1]/div[2]/div/div/div[2]/div[15]/div[1]/a/img"));
	    js.executeScript("arguments[0].scrollIntoView(true)", element);
	    Thread.sleep(3000);

	}
	@Test
	void testBuy() throws InterruptedException {
	    webDriver.findElement(By.xpath("/html/body/main/header/nav[2]/div/div[2]/div[1]/div/div[2]/div/div/div/form/div/input")).sendKeys("Klime");
	    webDriver.findElement(By.xpath("/html/body/main/header/nav[2]/div/div[2]/div[1]/div/div[2]/div/div/div/form/div/span/button")).click();
	    Thread.sleep(5000);
	    webDriver.findElement(By.xpath("/html/body/main/header/nav[2]/div/div[2]/div[2]/ul[1]/li/div/div/div[1]/a/div[1]")).click();
	    Thread.sleep(5000);
		webDriver.findElement(By.xpath("//*[@id=\"j_username\"]")).sendKeys("ahmed.babic@stu.ibu.edu.ba");
		Thread.sleep(2000);
		webDriver.findElement(By.xpath("/html/body/main/div[5]/div/div[1]/div[1]/div/div/form/div[2]/input")).sendKeys("Software1!");
		webDriver.findElement(By.xpath("/html/body/main/div[5]/div/div[1]/div[1]/div/div/form/button")).click();
		Thread.sleep(3000);
	    webDriver.findElement(By.xpath("/html/body/main/div[5]/div/div[1]/div[2]/div/div[1]/div[2]/form/div[2]/div/div/div[2]/input")).sendKeys("Ahmed");
	    webDriver.findElement(By.xpath("/html/body/main/div[5]/div/div[1]/div[2]/div/div[1]/div[2]/form/div[2]/div/div/div[3]/input")).sendKeys("Babic");
	    webDriver.findElement(By.xpath("/html/body/main/div[5]/div/div[1]/div[2]/div/div[1]/div[2]/form/div[2]/div/div/div[4]/input")).sendKeys("Klime00");
	    webDriver.findElement(By.xpath("/html/body/main/div[5]/div/div[1]/div[2]/div/div[1]/div[2]/form/div[2]/div/div/div[5]/input")).sendKeys("Klime");
	    webDriver.findElement(By.xpath("/html/body/main/div[5]/div/div[1]/div[2]/div/div[1]/div[2]/form/div[2]/div/div/div[6]/input")).sendKeys("0000");
	    webDriver.findElement(By.xpath("/html/body/main/div[5]/div/div[1]/div[2]/div/div[1]/div[2]/form/div[2]/div/div/div[7]/input")).sendKeys("0000");
		webDriver.findElement(By.xpath("/html/body/main/div[5]/div/div[1]/div[2]/div/div[1]/div[2]/form/div[3]/div[1]/div/label/input[1]")).click();
		webDriver.findElement(By.xpath("/html/body/main/div[5]/div/div[1]/div[2]/div/div[1]/div[2]/form/div[3]/div[2]/div/label/input[1]")).click();
	}
}
