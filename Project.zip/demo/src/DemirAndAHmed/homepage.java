package DemirAndAHmed;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import java.time.Duration;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

class homepage {
	private static WebDriver webDriver;
	private static String baseUrl;
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\Demir\\Desktop\\chromedriver.exe");
			webDriver = new ChromeDriver();
			baseUrl = "https://www.ekupi.ba/bs/";
			webDriver.get(baseUrl);	
			webDriver.manage().window().maximize();
			Thread.sleep(2000);	
			if (webDriver.findElement(By.xpath("/html/body/div[7]/div[2]/div/webpushrpromptconatiner/webpushrwppromptbox2_wrapper/webpushrpromptbox2/webpushrpromptbuttons2/webpushrpromptbtndeny2")).isDisplayed()){
				webDriver.findElement(By.xpath("/html/body/div[7]/div[2]/div/webpushrpromptconatiner/webpushrwppromptbox2_wrapper/webpushrpromptbox2/webpushrpromptbuttons2/webpushrpromptbtndeny2")).click();
			}
	}
	@AfterAll
	static void tearDownAfterClass() throws Exception {
	    Thread.sleep(2000);
		webDriver.close();
	}
	@Test
	void testLogo() throws InterruptedException {
		webDriver.navigate().to(baseUrl + "Apple");
		assertTrue("https://www.ekupi.ba/bs/Apple", true);
		Thread.sleep(2000);
		webDriver.findElement(By.xpath("/html/body/main/header/nav[1]/div/div[1]/div/div/div/a/img")).click();
		String url1 = webDriver.getCurrentUrl();
		assertEquals("https://www.ekupi.ba/bs/", url1);
		Thread.sleep(2000);
	}
	
	@Test
	void testMenu() throws InterruptedException {
	webDriver.findElement(By.xpath("/html/body/main/header/nav[3]/div/ul[2]/li[2]/span/a")).click();
	assertTrue("https://www.ekupi.ba/bs/Apple", true);
	
	webDriver.findElement(By.linkText("Kućanski aparati")).click();
	assertTrue("https://www.ekupi.ba/bs/Ku%C4%87anski-aparati/c/10003", true);
	
	webDriver.findElement(By.linkText("Klime")).click();
	assertTrue("https://www.ekupi.ba/bs/bs/Ku%C4%87anski-aparati/Grijanje-i-hla%C4%91enje/Klima-ure%C4%91aji/c/10025", true);
	
	webDriver.findElement(By.xpath("/html/body/main/header/nav[3]/div/ul[2]/li[6]/span[1]/a")).click();
	assertTrue("https://www.ekupi.ba/bs/Ra%C4%8Dunari/c/10001", true);
	
	webDriver.findElement(By.linkText("Televizori")).click();
	assertTrue("https://www.ekupi.ba/bs/Elektronika/Televizori-i-oprema/c/10102", true);
	
	webDriver.findElement(By.linkText("Mobiteli")).click();
	assertTrue("https://www.ekupi.ba/bs/Elektronika/Mobiteli-i-dodaci/c/10017", true);
	
	webDriver.findElement(By.xpath("/html/body/main/header/nav[3]/div/ul[2]/li[9]/span[1]/a")).click();
	assertTrue("https://www.ekupi.ba/bs/Elektronika/c/10002", true);
	
	webDriver.findElement(By.xpath("/html/body/main/header/nav[3]/div/ul[2]/li[10]/span/a")).click();
	assertTrue("https://www.ekupi.ba/bs/Elektronika/Gaming/c/10018", true);
	
	webDriver.findElement(By.linkText("Dom, vrt i alati")).click();
	assertTrue("https://www.ekupi.ba/bs/Dom%2C-vrt-i-alati/c/10006", true);
	
	webDriver.findElement(By.linkText("Sport")).click();
	assertTrue("https://www.ekupi.ba/bs/Sport/c/10004", true);
	
	webDriver.findElement(By.xpath("/html/body/main/header/nav[3]/div/ul[2]/li[14]/span[1]/a")).click();
	assertTrue("https://www.ekupi.ba/bs/Auto-i-moto-oprema/c/10005", true);
	
	webDriver.findElement(By.xpath("/html/body/main/header/nav[3]/div/ul[2]/li[15]/span[1]/a")).click();
	assertTrue("https://www.ekupi.ba/bs/Igra%C4%8Dke-i-dje%C4%8Dja-oprema/c/10008", true);
	
	webDriver.findElement(By.xpath("/html/body/main/header/nav[3]/div/ul[2]/li[16]/span[1]/a")).click();
	assertTrue("https://www.ekupi.ba/bs/Parfumerija/c/10055", true);
	
	webDriver.findElement(By.xpath("/html/body/main/header/nav[3]/div/ul[2]/li[17]/span[1]/a")).click();
	assertTrue("https://www.ekupi.ba/bs/Supermarket/c/10011", true);
	
	webDriver.findElement(By.linkText("Čišćenje zaliha")).click();
	assertTrue("https://www.ekupi.ba/bs/Ko-prvi-njegovo", true);
}
	@Test
	void testNeg() throws InterruptedException {
		webDriver.navigate().to(baseUrl + "Apple");
		String url2 = webDriver.getCurrentUrl();
		assertNotEquals("https://www.ekupi.ba/bs/Sport/c/10004", url2);
	}
	@Test
	void testAds() throws InterruptedException {
		webDriver.findElement(By.xpath("//*[@id=\"jumbo-slider\"]/div[1]/div/div[1]/a/picture/img")).click();
    	assertTrue("https://www.ekupi.ba/72-Sata", true);
    	Thread.sleep(2000);
    	webDriver.navigate().back();
		webDriver.findElement(By.xpath("//*[@id=\"jumbo-slider\"]/div[1]/div/div[2]/a/picture/img")).click();
    	assertTrue("https://www.ekupi.ba/Ubodi-popust", true);
	}
	@Test
	void testOS() throws InterruptedException {
		webDriver.findElement(By.cssSelector("body > main > div.main__inner-wrapper > div.content > div > a > picture > img")).click();
    	assertTrue("https://www.ekupi.ba/Zasto-kupovati-na-eKupi", true);
    	Thread.sleep(1000);
		JavascriptExecutor js = (JavascriptExecutor)webDriver; 
        js.executeScript("window.scrollBy(0,300)");
    	webDriver.findElement(By.linkText("Vizija i misija")).click();
    	assertTrue("https://www.ekupi.ba/Vizija-i-misija", true);  
    	Thread.sleep(1000);
    	webDriver.findElement(By.linkText("Zašto kupovati na eKupi")).click();
    	assertTrue("https://www.ekupi.ba/Zasto-kupovati-na-eKupi", true);  
    	Thread.sleep(1000);
        js.executeScript("window.scrollBy(0,300)");
    	webDriver.findElement(By.linkText("Gdje poslujemo")).click();
    	assertTrue("https://www.ekupi.ba/Gdje-poslujemo", true);  
    	Thread.sleep(1000);
    	webDriver.findElement(By.linkText("Ko je Kupko?")).click();
    	assertTrue("https://www.ekupi.ba/Gdje-poslujemo", true);
    	Thread.sleep(1000);
    	webDriver.findElement(By.linkText("Posao na eKupi")).click();
    	assertTrue("https://careers.ekupi.eu/", true);
	}
	@Test
	void testSearch() throws InterruptedException {
		webDriver.findElement(By.xpath("//*[@id=\"webpushr-deny-button\"]")).click();
		WebElement search = webDriver.findElement(By.xpath("//*[@id=\"js-site-search-input\"]"));
		search.sendKeys("mobiteli");
		webDriver.findElement(By.xpath("/html/body/main/header/nav[2]/div/div[2]/div[1]/div/div[2]/div/div/div/form/div/span/button/span")).click();
    	assertTrue("https://www.ekupi.ba/bs/Elektronika/Mobiteli-i-dodaci/Pametni-telefoni/c/10087", true);
	}
	@Test
	void testNew() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor)webDriver; 
        js.executeScript("window.scrollBy(0,3500)");
		WebElement search = webDriver.findElement(By.xpath("//*[@id=\"fieldName\"]"));
		search.sendKeys("Ahmed");
		WebElement search1 = webDriver.findElement(By.xpath("//*[@id=\"fieldEmail\"]"));
		search1.sendKeys("ahmed.babic@stu.ibu.edu.ba");
		WebElement search2 = webDriver.findElement(By.xpath("//*[@id=\"fieldijtiuyu\"]"));
		search2.sendKeys("0000000");
		Thread.sleep(2000);
		webDriver.findElement(By.xpath("//*[@id=\"subForm\"]/button")).click();
		Thread.sleep(1000);
	}
}
