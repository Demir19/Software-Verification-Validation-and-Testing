package DemirAndAHmed;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

class Profile {
	private static WebDriver webDriver;
	private static String baseUrl;
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Demir\\Desktop\\chromedriver.exe");
		webDriver = new ChromeDriver();
		baseUrl = "https://www.ekupi.ba/bs/";
		webDriver.get(baseUrl);	
		webDriver.manage().window().maximize();
		Thread.sleep(2000);	
		if (webDriver.findElement(By.xpath("/html/body/div[7]/div[2]/div/webpushrpromptconatiner/webpushrwppromptbox2_wrapper/webpushrpromptbox2/webpushrpromptbuttons2/webpushrpromptbtndeny2")).isDisplayed()){
			webDriver.findElement(By.xpath("/html/body/div[7]/div[2]/div/webpushrpromptconatiner/webpushrwppromptbox2_wrapper/webpushrpromptbox2/webpushrpromptbuttons2/webpushrpromptbtndeny2")).click();
		}
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	    Thread.sleep(2000);
		webDriver.close();
	}

	@Test
	void test() throws InterruptedException {
		    webDriver.findElement(By.xpath("/html/body/main/header/nav[2]/div/div[2]/div[2]/ul[2]/li/a")).click();
		    webDriver.findElement(By.xpath("//*[@id=\"register.title\"]/option[2]")).click();
			webDriver.findElement(By.xpath("//*[@id=\"register.firstName\"]")).sendKeys("Ahmed");
			webDriver.findElement(By.xpath("//*[@id=\"register.lastName\"]")).sendKeys("Babic");
			webDriver.findElement(By.xpath("//*[@id=\"register.email\"]")).sendKeys("ahmed.babic@stu.ibu.edu.ba");
			Thread.sleep(2000);
			JavascriptExecutor js = (JavascriptExecutor)webDriver; 
	        js.executeScript("window.scrollBy(0,500)");
			webDriver.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys("Software1!");
			webDriver.findElement(By.xpath("//*[@id=\"register.checkPwd\"]")).sendKeys("Software1!");
			webDriver.findElement(By.xpath("/html/body/main/div[5]/div/div/div[2]/div/div/div/form/div[8]/div/label/input")).click();
			webDriver.findElement(By.xpath("/html/body/main/div[5]/div/div/div[2]/div/div/div/form/div[9]/div/label/input[1]")).click();
			webDriver.findElement(By.xpath("//*[@id=\"register-submit-btn\"]")).click();
			Thread.sleep(10000);
	}
	@Test
	void testLogin() throws InterruptedException {
		    webDriver.findElement(By.xpath("/html/body/main/header/nav[2]/div/div[2]/div[2]/ul[2]/li/a")).click();
			webDriver.findElement(By.xpath("//*[@id=\"j_username\"]")).sendKeys("ahmed.babic@stu.ibu.edu.ba");
			Thread.sleep(1000);
			webDriver.findElement(By.xpath("/html/body/main/div[5]/div/div/div[1]/div/div/div/form/div[2]/input")).sendKeys("Software1!");
			webDriver.findElement(By.xpath("//*[@id=\"submit\"]")).click();
			webDriver.findElement(By.xpath("/html/body/main/header/nav[2]/div/div[2]/div[2]/ul[2]/li[1]")).isDisplayed();
			Thread.sleep(3000);
	}
	@Test
	void testLogout() throws InterruptedException {
		    webDriver.findElement(By.xpath("/html/body/main/header/nav[2]/div/div[2]/div[2]/ul[2]/li[3]/a")).click();
			webDriver.findElement(By.xpath("/html/body/main/header/nav[2]/div/div[2]/div[2]/ul[2]/li/a")).isDisplayed();
			Thread.sleep(3000);
	}
}
